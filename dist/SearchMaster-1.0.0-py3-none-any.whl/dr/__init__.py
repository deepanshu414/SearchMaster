import cv2
import pyautogui
import numpy as np
import os
import datetime
import pandas as pd
import threading
from pathlib import Path
from moviepy.editor import VideoFileClip

def convert():
    def convert_avi_to_mp4(avi_file, mp4_file):
        try:
            video = VideoFileClip(avi_file)
            video.write_videofile(mp4_file, codec='libx264')
            os.remove(avi_file)
        except Exception as e:
            print("An error occurred:", str(e))
    home=Path.home()
    complete_path=os.path.join(home,"Record_for_recording")
    folder_name=os.path.join(complete_path,"recording")
    for root, dirs, files in os.walk(folder_name):
        for file in files:
            if file.endswith('.avi'):
                filen, file_extension = os.path.splitext(file)
                input_file=os.path.join(folder_name, file)
                output_file=os.path.join(folder_name, filen+'.mp4')
                convert_avi_to_mp4(input_file,output_file )
def stop(valuea):
    home=Path.home()
    complete_path=os.path.join(home,"Record_for_recording")
    file_name=os.path.join(complete_path,"count")
    cout=os.path.join(file_name,"stop.txt")
    if(valuea.lower()=="stop"):
        with open(cout, 'w') as file:
            file.write(str(valuea.lower()))
def main(user):
    current=datetime.datetime.now()
    minute=current.minute
    home=Path.home()
    complete_path=os.path.join(home,"Record_for_recording")
    if not os.path.exists(complete_path):
        os.makedirs(complete_path)
    else:
        pass
    file_name=os.path.join(complete_path,"count")
    folder_name=os.path.join(complete_path,"recording")
    data_folder=os.path.join(complete_path,"data_store")
    if not os.path.exists(file_name):
        os.makedirs(file_name)
    else:
        pass
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    else:
        pass
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    else:
        pass
    cou=os.path.join(file_name,"count_recording_name.txt")
    if not os.path.exists(cou):
        with open(cou, 'w') as file:
                file.write(str("0"))
    else:
        pass
    cout=os.path.join(file_name,"stop.txt")
    if not os.path.exists(cout):
        with open(cout, 'w') as file:
                file.write(str("run"))
    else:
        with open(cout, 'w') as file:
            file.write(str("run"))
    dat=os.path.join(data_folder,"record.xlsx")
    if not os.path.exists(dat):
        df=pd.DataFrame({"R_name":[""],"d and t":[""],"Password":[""],"Match":[""]})
        df.to_excel(dat,index=False)
    else:
        pass
    def info(new_row):
        try:
            data=pd.read_excel(dat)
            df = pd.concat([data, pd.DataFrame([new_row])], ignore_index=True)
            df.to_excel(dat, index=False)
        except FileNotFoundError as e:
            print(e)
    def record_video():
            try:
                with open(cou, 'r') as file:
                    file_content = file.read()
                f = file_content
                screen_size = (1920, 1080)
                codec = cv2.VideoWriter_fourcc(*"XVID")
                b = f"record_{f}.avi"
                output = cv2.VideoWriter(os.path.join(folder_name, b), codec, 30.0, screen_size)
                record = {"R_name": str(b), "d and t": str(current), "Password": str(minute), "Match": "Yes"}
                info(record)
                while True:
                    img = pyautogui.screenshot()
                    frame = np.array(img)
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    output.write(frame)
                    with open(cout, 'r') as file:
                        av = file.read()
                    if av.lower() == "stop":
                        break
                output.release()
                with open(cou, 'w') as file:
                    file.write(str(int(f) + int(1)))
            except:
                pass
    if str(user) == str(minute):
        threading.Thread(target=record_video).start()
    else:
        record = {"R_name": "-", "d and t": str(current), "Password": str(minute), "Match": "No"}
        info(record)
        print("Wrong password")
